using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.HttpOverrides; // <-- reverse proxy support
using System.Net;
using SimpleSignalR.Hubs; // your hub

var builder = WebApplication.CreateBuilder(args);

// MVC + Views
builder.Services.AddControllersWithViews();

// SignalR
builder.Services.AddSignalR();

var app = builder.Build();

// --------------------
// 1) Reverse proxy headers (very early)
// --------------------
var fwd = new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto,
    ForwardLimit = 1 // trust only 1 proxy hop
};
fwd.KnownProxies.Add(IPAddress.Loopback); // OLS forwards from 127.0.0.1
app.UseForwardedHeaders(fwd);

// --------------------
// 2) Error handling / HTTPS
// --------------------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// --------------------
// 3) Routes
// --------------------

// MVC
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// SignalR hub
app.MapHub<ChatHub>("/hub");

// Health & debug info
app.MapGet("/healthz", () =>
    Results.Ok(new { ok = true, time = DateTimeOffset.UtcNow }));

app.MapGet("/_debug", (HttpContext ctx) =>
    Results.Ok(new
    {
        scheme = ctx.Request.Scheme,
        host = ctx.Request.Host.Value,
        clientIp = ctx.Connection.RemoteIpAddress?.ToString(),
        xff = ctx.Request.Headers["X-Forwarded-For"].ToString(),
        xfp = ctx.Request.Headers["X-Forwarded-Proto"].ToString()
    })
);

app.Run();
